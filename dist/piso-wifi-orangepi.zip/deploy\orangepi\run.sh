#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/opt/piso-wifi"
VENV_PATH="${APP_ROOT}/.venv"

cd "${APP_ROOT}"
exec "${VENV_PATH}/bin/python" app.py
